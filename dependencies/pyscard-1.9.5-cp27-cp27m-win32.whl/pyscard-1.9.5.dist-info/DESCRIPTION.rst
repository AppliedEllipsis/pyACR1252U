Smartcard package for Python


